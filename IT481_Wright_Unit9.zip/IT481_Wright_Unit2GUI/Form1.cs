﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace IT481_Wright_Unit2GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void form1_load(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("form1_load() called...");
            connectStatus.Text = "startup...";
            try
            {

                System.Diagnostics.Debug.WriteLine("within the try");
                SqlConnection connection = new SqlConnection(@"data source=djagczaltr\sqlexpress;initial catalog=northwind;integrated security=true;multipleactiveresultsets=true;app=entityframework");
                connection.Open();
                connectStatus.Text = "connection successful";
                connection.Close();

                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection conn = new SqlConnection(connstring);
                conn.Open();
                connectStatus.Text = "connection successful on startup";
                conn.Close();
            }
            catch (Exception ex)
            {
                connectStatus.Text = "error, " + ex;
            }
        }

        private void connect_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("connect_CLick() called...");
            connectStatus.Text = "Startup...";
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                connectStatus.Text = "Connection Successful";
                connection.Close();
            }
            catch (Exception ex)
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void showTable_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("connect_Click() called...");

            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                connectStatus.Text = "Retrieving Records...";
                command.Connection = connection;
                command.CommandText = "select * from Customers";
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                connectStatus.Text = "Retrieval Successful!";

                connection.Close();
            }

            catch ( Exception ex )
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void count_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("count_CLick() called...");
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                connection.Open();
                custCount.Text = "Counting Records...";
                command.Connection = connection;
                command.CommandText = "select count(*) from Customers";
                int count = (int)command.ExecuteScalar();
                custCount.Text = "Number of Customers: " + count;
                connection.Close();
            }

            catch (Exception ex)
            {
                custCount.Text = "Error, " + ex;
            }
        }

        private void showTable_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("showTable_Click() called...");

            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection conn = new SqlConnection(connstring);
                connection.Open();
                connectStatus.Text = "Retrieving Records...";
                command.Connection = connection;
                command.CommandText = "select * from Customers";
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                connectStatus.Text = "Retrieval Successful!";
                Debug.Assert(thisusername == "User_Sales" || thisusername == "User_CEO", "only correct username can access data");
                if (thisusername == "User_Sales" || thisusername == "User_CEO")
                {
                    dataGridView1.Visible = true;
                    dataGridView2.Visible = false;
                    dataGridView3.Visible = false;
                }
                else
                {
                    dataGridView1.Visible = false;
                    dataGridView2.Visible = false;
                    dataGridView3.Visible = false;
                }
                connection.Close();
            }

            catch (Exception ex)
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void count_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("count_CLick() called...");
            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection conn = new SqlConnection(connstring);
                connection.Open();
                custCount.Text = "Counting Records...";
                command.Connection = connection;
                command.CommandText = "select count(*) from Customers";
                int count = (int)command.ExecuteScalar();
                custCount.Text = "Number of Customers: " + count;
                connection.Close();
            }

            catch (Exception ex)
            {
                custCount.Text = "Error, " + ex;
            }
        }

        private void buttonShowEmployees_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("buttonShowEmployees_Click() called...");

            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection conn = new SqlConnection(connstring);
                connection.Open();
                connectStatus.Text = "Retrieving Records...";
                command.Connection = connection;
                command.CommandText = "select * from Employees";
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                connectStatus.Text = "Retrieval Successful!";
                Debug.Assert(thisusername == "User_HR" || thisusername == "User_CEO", "only correct username can access data");
                if (thisusername == "User_HR" || thisusername == "User_CEO")
                {
                    dataGridView2.Visible = true;
                    dataGridView1.Visible = false;
                    dataGridView3.Visible = false;
                }
                else
                {
                    dataGridView1.Visible = false;
                    dataGridView2.Visible = false;
                    dataGridView3.Visible = false;
                }

                connection.Close();
            }

            catch (Exception ex)
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void buttonDisplayOrders_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Debug.WriteLine("buttonDisplayOrders_Click() called...");

            try
            {
                System.Diagnostics.Debug.WriteLine("within the try");
                SqlCommand command = new SqlCommand();
                SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
                var datasource = @"djagczaltr\sqlexpress";
                var database = "northwind";

                var thisusername = Form2.username;
                var thispassword = Form2.password;
                string connstring = @"data source=" + datasource + ";initial catalog=" +
                database + ";persist security info=true;user id=" + thisusername + ";password=" +
                thispassword;
                SqlConnection conn = new SqlConnection(connstring);
                connection.Open();
                connectStatus.Text = "Retrieving Records...";
                command.Connection = connection;
                command.CommandText = "select * from Orders";
                SqlDataAdapter da = new SqlDataAdapter(command);
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                connectStatus.Text = "Retrieval Successful!";
                Debug.Assert(thisusername == "User_Sales" || thisusername == "User_CEO", "only correct username can access data");
                if (thisusername == "User_Sales" || thisusername == "User_CEO")
                {
                    
                    dataGridView3.Visible = true;
                    dataGridView2.Visible = false;
                    dataGridView1.Visible = false;
                }
              else
                {
                    dataGridView1.Visible = false;
                    dataGridView2.Visible = false;
                    dataGridView3.Visible = false;
                }

                connection.Close();
            }

            catch (Exception ex)
            {
                connectStatus.Text = "Error, " + ex;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'northwindDataSet.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.northwindDataSet.Orders);
            // TODO: This line of code loads data into the 'northwindDataSet.Employees' table. You can move, or remove it, as needed.
            this.employeesTableAdapter.Fill(this.northwindDataSet.Employees);

        }
    }
}
