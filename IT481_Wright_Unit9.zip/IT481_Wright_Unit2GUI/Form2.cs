﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT481_Wright_Unit2GUI
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        public static string username = "";
        public static string password = "";
        public static int failCounter = 0;

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection(@"data source=DJAGCZALTR\SQLEXPRESS;initial catalog=Northwind;integrated security=True;MultipleActiveResultSets=True;App=EntityFramework");
            username = usernameText.Text;
            password = passwordText.Text;
            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter your username and password.");
            }
            else if (username.Length > 20 || username.Contains("|") || username.Contains("/"))
            {
                MessageBox.Show("Username is invalid, please insert valid username.");
            }
            else if (password.Length > 50 || password.Contains("|") || password.Contains("/"))
            {
                MessageBox.Show("Password is incorrect, please try again.");
            }
            else
            {
                var datasource = @"DJAGCZALTR\SQLEXPRESS";
                var database = "Northwind";
                var thisUsername = username;
                var thisPassword = password;
                string connString = @"Data Source=" + datasource + ";Initial Catalog=" +
                database + ";Persist Security Info=True;User ID=" + username + ";Password=" + password;
                SqlConnection conn = new SqlConnection(connString);
                try
                {
                    conn.Open();
                    //MessageBox.Show("Connection Successful");

                    Form1 frm1 = new Form1();

                    frm1.Show();
                    this.Hide();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                    failCounter ++;
                    
                }

            }
            if (failCounter == 3) { this.Close(); }
        }
    }
}
